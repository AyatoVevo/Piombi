<?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.header','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>

    <?php if(session('message')): ?>
        <div class="alert alert-success text-center">
            <?php echo e(session('message')); ?>

        </div>
    <?php endif; ?>
        
    
    <section class="container-fluid bg-more">
        <div class="row row-height">
            <div class="col-12 wh d-flex flex-column justify-content-center align-items-center">
                <h2>Dai un occhiata ai nostri prodotti!</h2>
                <i class="fa-solid fa-arrow-down fa-2x"></i>
            </div>
        </div>
    </section>

    <section class="container-fluid">
        <div class="row row-height">

            
            <div class="col-12 col-md-4 col-lg-4 col-custom col1">
                <a href="<?php echo e(route('products')); ?>" class="anchorsize d-flex align-items-center justify-content-center"><h3 class="wh fs-2">Lancio</h3></a>               
            </div>
            <div class="col-12 col-md-4 col-lg-4 col-custom col2">
                <a href="<?php echo e(route('products')); ?>" class="anchorsize d-flex align-items-center justify-content-center"><h3 class="wh fs-2">Feeders</h3></a>
            </div>
            <div class="col-12 col-md-4 col-lg-4 col-custom col3">
                <a href="<?php echo e(route('products')); ?>" class="anchorsize d-flex align-items-center justify-content-center"><h3 class="wh fs-2">Inline</h3></a>
            </div>
           
        </div>

    </section>




 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?><?php /**PATH C:\Users\axely\Desktop\Progetti web\PiombiDiVale\resources\views/welcome.blade.php ENDPATH**/ ?>