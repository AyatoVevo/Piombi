<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    


     <?php $__currentLoopData = $info['orders']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <h4><?php echo e($order); ?></h4>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php $__currentLoopData = $info['quantities']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $quantity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <h4><?php echo e($quantity); ?></h4>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <p><?php echo e($info['email']); ?></p>

    <h4>More info:</h4>
    <p><?php echo e($info['message']); ?></p>
</body>
</html><?php /**PATH C:\Users\axely\Desktop\Progetti web\PiombiDiVale\resources\views/mail/order-submit-mail.blade.php ENDPATH**/ ?>