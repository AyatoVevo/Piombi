<?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="container-fluid p-5 bg-dark text-center wh">
        <div class="row justify-content-center">
            <h1 class="display-1">Richiedi un preventivo</h1>
        </div>
    </div>


    <section>
        <div class="container my-5">
            <div class="row justify-content-center">
                <div class="col-12 col-md-8 col-lg-8">
                    <?php if($errors->any()): ?>
                        <div class="alert">
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>
        
                    <form class="card p-5 shadow" action="<?php echo e(route('order.submit')); ?>" method="post">
                    <?php echo csrf_field(); ?>   
                    
                    <div class="mb-3 ">
                        <label for="email" class="form-label">Email</label>
                        <input type="email" name="email" class="form-control" id="email" value="<?php echo e(old('email') ?? Auth::user()->email); ?>">
                    </div>

                    <p class="mt-4">Seleziona prodotti</p>
        
                        <div class="row justify-content-center my-3">

                            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <div class="col-12 my-1" >
                        
                                    <label style="width: 60%">
                                        <input type="checkbox" name="orders[]"  value="<?php echo e($product->name); ?>">
                                        <?php echo e($product->name); ?>

                                    </label>
                                    <input style="width: 30%" type="number" name="quantities[]" placeholder="Quantità">
                                </div>
                                

                                
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        
                        
                        
                        <div class="my-3 d-flex flex-column">
                            <label for="message" class="form-label">Altre informazioni</label>
                            <textarea name="message" id="message" cols="30" rows="10"><?php echo e(old('message')); ?></textarea>
                        </div>

                        <div class="mt-2">
                            <button class="btn btn-info wh">Invia mail</button>
                        </div>
                    </form>
        
        
                </div>
            </div>
        </div>
    </section>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>




<?php /**PATH C:\Users\axely\Desktop\Progetti web\PiombiDiVale\resources\views/order.blade.php ENDPATH**/ ?>