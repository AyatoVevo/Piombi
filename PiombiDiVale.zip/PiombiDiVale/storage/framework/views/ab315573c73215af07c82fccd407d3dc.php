<footer class="bg-footer text-center text-white container-fluid">

    

        <div class="row justify-content-between">

            <div class="col-12 col-md-6 col-lg-4 my-4">
                <h3>Contatti</h3>
                <p>Telefono: (+39) 327-001-7469</p>
                <p>Email: placeholder</p>
            </div>

            <div class="col-12 col-md-6 col-lg-4 my-4">
                <form action="">
                    <!--Grid row-->
                    <div class="row d-flex justify-content-center">
                      <div class="col-12">
                        <p class="pt-2">
                          <strong>Iscriviti per ricevere promozioni e aggiornamenti!</strong>
                        </p>
                      </div>
            
                      <div class="col-md-5 col-8">

                          
                          <div class="form-outline form-white mb-4">
                              <input type="email" id="form5Example2" class="form-control" />
                              <label class="form-label" for="form5Example2">Indirizzo email</label>
                        </div>
                      </div>
            
                      <div class="col-auto">
            
                        <!-- Submit button -->
                        <button type="submit" class="btn btn-info mb-4">
                          Subscribe
                        </button>
                      </div>
                    </div>
                    <!--Grid row-->
                  </form>
            </div>
            
            <div class="col-12 col-md-6 col-lg-4 my-4 d-flex align-items-center justify-content-center">
                <a href="https://www.instagram.com/amici_del_self_maker/" target="blank"><i class="wh fa-brands fa-2x fa-instagram"></i>
                </a>
                <a class="mx-5" href="https://www.facebook.com/profile.php?id=100075854293564&paipv=0&eav=AfZizyC3AfiJu5wlDi8fXkBU-oJIe1VYOUawgnvDKxM5_vBR4zc4FaHNy5uKso6ysKs&_rdr" target="blank"><i class="wh fa-brands fa-2x fa-facebook"></i></a>
                <a href="https://www.youtube.com/@amicidelself-maker2963" target="blank"><i class="wh fa-brands fa-2x fa-youtube"></i></a>
            </div>
            
        </div>
    
</footer><?php /**PATH C:\Users\axely\Desktop\Progetti web\SelfMakersPesca\resources\views/components/footer.blade.php ENDPATH**/ ?>