<?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="container-fluid p-5 text-center wh">
        <div class="row justify-content-center">
            <h1 class="display-1">
                <?php echo e($product->name); ?>

            </h1>
        </div>
    </div>

    <div class="container">
        <div class="row justify-content-around">
            <div class="col-12 col-md-8">
                <img src="<?php echo e($product->img); ?>" alt="" class="img-fluid my-3">
                    <div class="text-center">
                        <h2><?php echo e($product->name); ?></h2>
                    </div>
                <hr>
                <p><?php echo e($product->description); ?></p>
                <div class="text-center">
                    <a href="<?php echo e(route('prodotti')); ?>" class="btn btn-info text-white">Torna indietro</a>
                </div>
            </div>
        </div>
    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?><?php /**PATH C:\Users\axely\Desktop\Progetti web\SelfMakersPesca\resources\views/product/show.blade.php ENDPATH**/ ?>