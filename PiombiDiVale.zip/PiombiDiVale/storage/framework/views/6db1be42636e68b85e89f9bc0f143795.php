<?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    

    <div class="container py-5">
        <div class="row justify-content-around">

            <div class="col-12 col-md-8 col-lg-5">
                <img src="<?php echo e(Storage::url($product->img)); ?>" alt="" class="img-fluid my-3">                    
            </div>

            <div class="col-lg-6 col-12 col-md-8 d-flex flex-column justify-content-start">       
                <h2 class="wh"><?php echo e($product->name); ?></h2>
                <p class="preserveLines wh"><?php echo e($product->body); ?></p>
                <a href="<?php echo e(route('products')); ?>" class="btn btn-info text-white align-self-end mt-5">Torna indietro</a>
            </div>
            
        </div>
        <?php if(Auth::user()->is_admin): ?>
            <a href="<?php echo e(route('product.show', compact('product'))); ?>" class="btn btn-info wh">Read</a>
            <a href="<?php echo e(route('product.edit', compact('product'))); ?>" class="btn btn-info wh">Edit</a>
            <form action="<?php echo e(route('product.destroy', compact('product'))); ?>" method="post" class="d-inline">
                <?php echo csrf_field(); ?>
                <?php echo method_field('delete'); ?>
                <button type="submit" class="btn btn-danger">Delete</button>
            </form>
        <?php endif; ?>
    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?><?php /**PATH C:\Users\axely\Desktop\Progetti web\PiombiDiVale\resources\views/product/show.blade.php ENDPATH**/ ?>