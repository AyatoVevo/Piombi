<div class="container-fluid m-nav bg-header">
    <div class="row hei-100 align-items-center">
        <div class="col-12">
            <h1 class="display-3 ms-3 text-custom">Piombi di Vale</h1>
        </div>
    </div>
</div><?php /**PATH C:\Users\axely\Desktop\Progetti web\SelfMakersPesca\resources\views/components/header.blade.php ENDPATH**/ ?>