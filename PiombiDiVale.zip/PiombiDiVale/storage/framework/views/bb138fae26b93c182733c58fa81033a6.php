<?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    
    <header class="bg-header-prodotti d-flex justify-content-start align-items-center ps-4">
        <h1 class="text-custom-prodotti">I nostri prodotti</h1>
    </header>

    
    <section class="bg-products">
        <div class="container">

            <div class="row justify-content-between">
                <div class="col-3 d-flex justify-content-center py-2">
                    <a href="<?php echo e(route('products')); ?>" class="fs-5 catBor">Tutti i prodotti</a>
                </div>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    
                    <div class="col-3 d-flex justify-content-center py-2">

                        <a href="<?php echo e(route('product.byCategory', ['category' => $category->id])); ?>" class="fs-5 catBor"><?php echo e($category->name); ?></a>
                    </div>
                    
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

        <?php if(session('message')): ?>
            <div class="alert alert-success text-center">
                <?php echo e(session('message')); ?>

            </div>
        <?php endif; ?>

            <div class="row w-100">

                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-12 col-md-6 col-lg-4 my-5 d-flex justify-content-center">
                
                    <div class="card" style="width: 18rem;">
                        <img src="<?php echo e(Storage::url($product->img)); ?>" class="img-fluid" alt="...">
                        <div class="card-body">
                            <h2 class="card-title fs-5"><?php echo e($product->name); ?></h2>
                            <p class="card-text"><?php echo e($product->description); ?></p>
                            <a href="<?php echo e(route('product.byCategory', ['category' => $product->category->id])); ?>" class=" fs-5"><?php echo e($product->category->name); ?></a>

                            <a href="<?php echo e(route('product.show', compact('product'))); ?>" class="btn btn-primary">Leggi di più!</a>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
            </div>

        </div>
    </section>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?><?php /**PATH C:\Users\axely\Desktop\Progetti web\PiombiDiVale\resources\views/product/index.blade.php ENDPATH**/ ?>