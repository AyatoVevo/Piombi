<?php return array (
  'register-passwords' => 'App\\Http\\Livewire\\RegisterPasswords',
);